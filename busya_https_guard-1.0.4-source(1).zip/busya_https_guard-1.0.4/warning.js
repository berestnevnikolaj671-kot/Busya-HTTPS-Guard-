'use strict';

const params = new URLSearchParams(location.search);
const httpUrl = params.get('target') || '';
const httpsUrl = params.get('https') || '';
const error = params.get('error') || '';

const httpUrlEl = document.getElementById('httpUrl');
const httpsUrlEl = document.getElementById('httpsUrl');
const errorTextEl = document.getElementById('errorText');
const visitBtn = document.getElementById('visitBtn');

httpUrlEl.textContent = httpUrl || 'Неизвестный HTTP-адрес';
httpsUrlEl.textContent = httpsUrl || 'Неизвестный HTTPS-адрес';

if (error) {
  errorTextEl.textContent = `Ошибка Firefox: ${error}`;
}

visitBtn.addEventListener('click', async () => {
  if (!/^http:\/\//i.test(httpUrl)) {
    return;
  }

  visitBtn.disabled = true;
  visitBtn.textContent = 'Открываю HTTP…';

  const ok = await browser.runtime.sendMessage({
    action: 'visitAnyway',
    url: httpUrl
  });

  if (!ok) {
    visitBtn.disabled = false;
    visitBtn.textContent = 'Всё равно открыть HTTP';
    errorTextEl.textContent = 'Не получилось открыть HTTP-адрес.';
  }
});
