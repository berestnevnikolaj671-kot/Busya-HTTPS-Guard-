'use strict';

// Busya HTTPS Guard
// v1.0.4:
// - Исправлен бесконечный цикл после кнопки «Всё равно посетить».
// - Разрешение HTTP теперь действует временно для вкладки + хоста, а не только для одного запроса.
// - При ручном открытии HTTP очищаются старые HTTPS-попытки.
// - Убрана кнопка «Назад» с предупреждения.

const HTTPS_ATTEMPTS = new Map();
const ALLOW_HTTP_UNTIL = new Map();

const ATTEMPT_TTL_MS = 2 * 60 * 1000;
const ALLOW_TTL_MS = 2 * 60 * 1000;
const HTTPS_FALLBACK_WARNING_MS = 12 * 1000;

function now() {
  return Date.now();
}

function key(tabId, url) {
  return `${tabId}::${url}`;
}

function tabHostKey(tabId, url) {
  try {
    const u = new URL(url);
    return `${tabId}::${u.hostname}`;
  } catch (_) {
    return `${tabId}::${url}`;
  }
}

function httpToHttps(url) {
  return url.replace(/^http:/i, 'https:');
}

function isHttpUrl(url) {
  return typeof url === 'string' && /^http:\/\//i.test(url);
}

function isHttpsUrl(url) {
  return typeof url === 'string' && /^https:\/\//i.test(url);
}

function isHttpAllowed(tabId, url) {
  const allowUntil = ALLOW_HTTP_UNTIL.get(tabHostKey(tabId, url));
  if (allowUntil && now() <= allowUntil) {
    return true;
  }

  if (allowUntil) {
    ALLOW_HTTP_UNTIL.delete(tabHostKey(tabId, url));
  }

  return false;
}

function allowHttpForTabHost(tabId, url) {
  ALLOW_HTTP_UNTIL.set(tabHostKey(tabId, url), now() + ALLOW_TTL_MS);
}

function cleanupMaps() {
  const t = now();

  for (const [k, value] of HTTPS_ATTEMPTS.entries()) {
    if (!value || t - value.createdAt > ATTEMPT_TTL_MS) {
      clearAttemptTimer(value);
      HTTPS_ATTEMPTS.delete(k);
    }
  }

  for (const [k, expiresAt] of ALLOW_HTTP_UNTIL.entries()) {
    if (!expiresAt || t > expiresAt) {
      ALLOW_HTTP_UNTIL.delete(k);
    }
  }
}

function clearAttemptTimer(attempt) {
  if (attempt && attempt.timerId) {
    clearTimeout(attempt.timerId);
    attempt.timerId = null;
  }
}

function clearAttemptsForTab(tabId) {
  for (const [k, attempt] of HTTPS_ATTEMPTS.entries()) {
    if (attempt && attempt.tabId === tabId) {
      clearAttemptTimer(attempt);
      HTTPS_ATTEMPTS.delete(k);
    }
  }
}

function findAttempt(tabId, url) {
  const exactKey = key(tabId, url);
  const exact = HTTPS_ATTEMPTS.get(exactKey);
  if (exact) {
    return [exactKey, exact];
  }

  for (const [k, attempt] of HTTPS_ATTEMPTS.entries()) {
    if (attempt && attempt.tabId === tabId && attempt.httpsUrl === url) {
      return [k, attempt];
    }
  }

  return [null, null];
}

async function tabStillOnAttempt(tabId, attempt) {
  try {
    const tab = await browser.tabs.get(tabId);
    if (!tab || !attempt) {
      return false;
    }

    return tab.url === attempt.httpsUrl || tab.url === attempt.originalUrl || tab.status === 'loading';
  } catch (_) {
    return false;
  }
}

async function showWarning(tabId, attempt, error) {
  if (!attempt || attempt.warningShown) {
    return;
  }

  // Если пользователь уже нажал «Всё равно посетить», предупреждение больше не показываем.
  if (isHttpAllowed(tabId, attempt.originalUrl)) {
    clearAttemptTimer(attempt);
    HTTPS_ATTEMPTS.delete(key(tabId, attempt.httpsUrl));
    return;
  }

  const attemptKey = key(tabId, attempt.httpsUrl);
  const stored = HTTPS_ATTEMPTS.get(attemptKey);
  if (!stored) {
    return;
  }

  if (!(await tabStillOnAttempt(tabId, attempt))) {
    return;
  }

  attempt.warningShown = true;
  clearAttemptTimer(attempt);
  HTTPS_ATTEMPTS.delete(attemptKey);

  const warningUrl = browser.runtime.getURL('warning.html')
    + `?target=${encodeURIComponent(attempt.originalUrl)}`
    + `&https=${encodeURIComponent(attempt.httpsUrl)}`
    + `&error=${encodeURIComponent(error || 'HTTPS_UNAVAILABLE')}`;

  browser.tabs.update(tabId, { url: warningUrl }).catch(() => {});
}

async function probeHttps(tabId, attempt) {
  try {
    await fetch(attempt.httpsUrl, {
      method: 'HEAD',
      credentials: 'include',
      cache: 'no-store',
      redirect: 'follow'
    });

    clearAttemptTimer(attempt);
    HTTPS_ATTEMPTS.delete(key(tabId, attempt.httpsUrl));
  } catch (headError) {
    try {
      await fetch(attempt.httpsUrl, {
        method: 'GET',
        credentials: 'include',
        cache: 'no-store',
        redirect: 'follow'
      });

      clearAttemptTimer(attempt);
      HTTPS_ATTEMPTS.delete(key(tabId, attempt.httpsUrl));
    } catch (getError) {
      await showWarning(tabId, attempt, getError && getError.message ? getError.message : 'HTTPS_FETCH_FAILED');
    }
  }
}

setInterval(cleanupMaps, 60 * 1000);

browser.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.type !== 'main_frame' || details.tabId < 0 || !isHttpUrl(details.url)) {
      return {};
    }

    // Пользователь нажал «Всё равно посетить».
    // Разрешаем HTTP временно для этой вкладки и хоста, чтобы не было цикла.
    if (isHttpAllowed(details.tabId, details.url)) {
      return {};
    }

    const httpsUrl = httpToHttps(details.url);
    const attempt = {
      tabId: details.tabId,
      originalUrl: details.url,
      httpsUrl,
      createdAt: now(),
      timerId: null,
      warningShown: false
    };

    clearAttemptsForTab(details.tabId);

    attempt.timerId = setTimeout(() => {
      showWarning(details.tabId, attempt, 'HTTPS_TIMEOUT').catch(() => {});
    }, HTTPS_FALLBACK_WARNING_MS);

    HTTPS_ATTEMPTS.set(key(details.tabId, httpsUrl), attempt);
    probeHttps(details.tabId, attempt).catch(() => {});

    return { redirectUrl: httpsUrl };
  },
  { urls: ['http://*/*'], types: ['main_frame'] },
  ['blocking']
);

browser.webNavigation.onCompleted.addListener(
  (details) => {
    if (details.frameId !== 0 || details.tabId < 0 || !isHttpsUrl(details.url)) {
      return;
    }

    clearAttemptsForTab(details.tabId);
  },
  { url: [{ schemes: ['https'] }] }
);

browser.webNavigation.onErrorOccurred.addListener(
  (details) => {
    if (details.frameId !== 0 || details.tabId < 0 || !isHttpsUrl(details.url)) {
      return;
    }

    const [, attempt] = findAttempt(details.tabId, details.url);
    if (!attempt) {
      return;
    }

    showWarning(details.tabId, attempt, details.error || 'HTTPS_NAVIGATION_ERROR').catch(() => {});
  },
  { url: [{ schemes: ['https'] }] }
);

browser.webRequest.onErrorOccurred.addListener(
  (details) => {
    if (details.type !== 'main_frame' || details.tabId < 0 || !isHttpsUrl(details.url)) {
      return;
    }

    const [, attempt] = findAttempt(details.tabId, details.url);
    if (!attempt) {
      return;
    }

    showWarning(details.tabId, attempt, details.error || 'HTTPS_REQUEST_ERROR').catch(() => {});
  },
  { urls: ['https://*/*'], types: ['main_frame'] }
);

browser.tabs.onRemoved.addListener((tabId) => {
  clearAttemptsForTab(tabId);
});

browser.runtime.onMessage.addListener((message, sender) => {
  const tabId = sender && sender.tab && sender.tab.id;

  if (tabId === undefined || tabId === null || tabId < 0) {
    return Promise.resolve(false);
  }

  if (message && message.action === 'visitAnyway' && isHttpUrl(message.url)) {
    // Главное исправление: разрешаем HTTP ДО перехода и очищаем старые попытки HTTPS.
    allowHttpForTabHost(tabId, message.url);
    clearAttemptsForTab(tabId);

    return browser.tabs.update(tabId, { url: message.url })
      .then(() => true)
      .catch(() => false);
  }

  return Promise.resolve(false);
});
